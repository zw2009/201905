function delExtension(str){
	var reg = /\.\w+$/;
 	return str.replace(reg,'');
}

function getRootPath(){

    //获取当前网址，如： http://localhost:8083/maintain/share/meun.jsp

    var curWwwPath=window.document.location.href;

    //获取主机地址之后的目录，如： maintain/share/meun.jsp

    var pathName=window.document.location.pathname;

    var pos=curWwwPath.indexOf(pathName);

    //获取主机地址，如： http://localhost:8083

    var localhostPaht=curWwwPath.substring(0,pos);

    //获取带"/"的项目名，如：/maintain

    var projectName=pathName.substring(0,pathName.substr(1).indexOf('/')+1);

    return(localhostPaht+projectName);

}

function uploadify(){
	if (arguments.length == 0) return false;
	var param=arguments[0];
	if (typeof param != "object") return false;
	
	var options={
		id:'#file_upload',
		uploader:'',
		img_input:'picture',
		alt_input:'alt'
	}
	
	if(param.id!=undefined) 		options.id			= param.id;
	if(param.uploader!=undefined) 	options.uploader	= param.uploader;
	if(param.img_input!=undefined)	 options.img_input	= param.img_input;
	if(param.alt_input!=undefined) 	options.alt_input	= param.alt_input;
	
	var swf=getRootPath()+"/Public/Common/plugs/uploadify/uploadify.swf";
	
	$(options.id).uploadify({
		'auto':true,
		'fileTypeExts':'*.jpg;*.jpge;*.gif;*.png',
		'fileSizeLimit' : '1MB',
		'queueSizeLimit':'5',
		'buttonClass':'upload_btn',
		'buttonText':'选择文件',
		'width':85,
		'height':29,
		'removeCompleted':false,
		'removeTimeout':0,
		'swf'      : swf,
		'uploader' : options.uploader,
		'overrideEvents': ['onSelectError', 'onDialogClose'],
		'onSelectError':function(file, errorCode, errorMsg){
			 switch (errorCode) {  
                case -100:  
                    alert("上传的文件数量已经超出系统限制的" + $('#file_upload').uploadify('settings', 'queueSizeLimit') + "个文件！");  
                    break;  
                case -110:  
                    alert("文件 [" + file.name + "] 大小超出系统限制的" + $('#file_upload').uploadify('settings', 'fileSizeLimit') + "大小！");  
                    break;  
                case -120:  
                    alert("文件 [" + file.name + "] 大小异常！");  
                    break;  
                case -130:  
                    alert("文件 [" + file.name + "] 类型不正确！");  
                    break;  
            }  
            return false; 
		},
		'onSelect':function(file){
			$('#' + file.id).append("<input type='hidden' name='"+options.img_input+"[]' class='"+file.id+"'><input type='text' name='"+options.alt_input+"[]' class='"+file.id+"_alt form-control'>")
		},
		'onCancel':function(file,event){
			$('#' + file.id).remove();
		},
		'onUploadSuccess':function(file, data, response){
			if(response==true){
				var res=JSON.parse(data);
				if(res.status==0){
					alert(res.info);
					$('#' + file.id).remove();
					return false;
				}else{
					$('#' + file.id).find('.data').html("<img src='"+getRootPath()+'/Public/Uploads/images/'+res.data.path+"' width='100%'>");
					$('#' + file.id).find('.'+file.id).val(res.data.path);
					$('#' + file.id).find('.'+file.id+'_alt').val(delExtension(res.data.alt));
					return false;
				}
			}
		}
	});
}
