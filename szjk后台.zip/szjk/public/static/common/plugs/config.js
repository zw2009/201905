require.config({
    urlArgs: '', 
    baseUrl: '/static',
    paths: {
		'jquery':'common/plugs/jquery-1.10.2.min',
		'tpl':'common/plugs/tmodjs',
		'flexslider':'common/plugs/FlexSlider/jquery.flexslider',
		'swiper':'common/plugs/swiper/swiper-3.3.1.jquery.min',
		'modal':'common/plugs/bootstrap.modal/bootstrap.modal',
		'core':'common/plugs/core/core',
		'spinner':'common/plugs/spinner/jquery.spinner',
		'icheck':'common/plugs/icheck/icheck.min',
		'swipeout':'common/plugs/swipeout/swipeout',
		'distpicker':'common/plugs/distpicker/distpicker',
		'datepicker':'common/plugs/iosDatePicker/iosDatePicker',
		'lazyload':'common/plugs/lazyload/jquery.lazyload.min',
		'css': 'common/plugs/css.min'
    },
    shim: {
		'flexslider': {
            exports: "$",
			deps: ['jquery','css!common/plugs/FlexSlider/flexslider.css']
		},
		'jquery.swiper':{
			deps: ['jquery','css!common/plugs/swiper/swiper-3.3.1.min.css']
		},
		'modal':{
			deps: ['jquery','css!common/plugs/bootstrap.modal/modal.css']
		},
		'spinner':{
			deps: ['jquery','css!common/plugs/spinner/jquery.spinner.css']
		},
		'swipeout':{
			deps: ['jquery','css!common/plugs/swipeout/swipeout.css']
		},
		'icheck':{
			deps: ['jquery','css!common/plugs/icheck/icheck.css']
		},
		'core':{
			deps: ['css!common/plugs/core/core.css']
		}
    }
});