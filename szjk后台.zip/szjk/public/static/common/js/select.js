$(document).ready(function(){
	select_width($('.ui-combo-wrap'));
	$('.ui-combo-wrap').each(function(){
		refresh_select($(this));
	})
	$('body').click(function(e) {
	  if($(e.target).hasClass('ui-combo-wrap')==false && $(e.target).hasClass('input-txt')==false && $(e.target).hasClass('trigger')==false){
	  		$('.ui-combo-wrap').removeClass('ui-combo-active');
			$('.ui-combo-wrap').next().hide();
	  }
	})
	$('.ui-combo-wrap').click(function(){
		open_select($(this));	
	});
	$('.list-item').click(function(){
		select_option($(this));
	})
});

function open_select($obj){
	select_width($obj);
	if($obj.hasClass('ui-combo-active')){
		$obj.removeClass('ui-combo-active');
		$obj.next().hide();
	}else{
		$obj.addClass('ui-combo-active');
		$obj.next().show();
	}
}

function select_width($obj){
	var width=$obj.width();
	var drop_width=$obj.next().width();
	if(width<drop_width){
		$obj.width(drop_width);
	}else{
		$obj.next().width(width);
	}
}

function select_option($obj){
	var parents=$obj.parents('.droplist');
	parents.find('.list-item.selected').removeClass('selected');
	$obj.addClass('selected');
	$('input[name="'+parents.data('name')+'"]').val($obj.data('value'));
	$obj.parents('.ui-combo').find('.input-txt').text($obj.text());
}

function refresh_select($obj){
	var sel_value=$obj.find('input[type="hidden"]').val();
	if(sel_value==''){
		sel_value=$obj.next().find('.list-item').eq(0).data('value');
	}
	$obj.next().find('.list-item').removeClass('.selected');
	if(sel_value==null){
		$obj.find('input[type="hidden"]').val('');
		$obj.find('.input-txt').text('');
	}else{
		$obj.next().find('.list-item').each(function(){
			if($(this).data('value')==sel_value){
				select_option($(this));
			}
		})
	}
	
}