<?php
namespace app\common\model;
class Feedback extends Base{
	protected $autoWriteTimestamp = true;

	
}

?>
