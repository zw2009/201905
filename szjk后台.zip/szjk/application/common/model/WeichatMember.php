<?php
namespace app\common\model;
class WeichatMember extends Base{
	protected $autoWriteTimestamp = true;
}

?>
