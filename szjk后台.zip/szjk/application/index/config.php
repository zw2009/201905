<?php
return [
	'view_replace_str'       => [
		'__CSS__'=>'/static/index/css',
		'__JS__'=>'/static/index/js',
		'__IMG__'=>'/static/index/images',
		'__COMMON__'=>'/static/common',
		'__PLUGS__'=>'/static/common/plugs',
		'__UPIMG__'=>'/uploads/image/',
	]
];