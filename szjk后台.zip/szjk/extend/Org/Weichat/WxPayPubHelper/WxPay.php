<?php

include_once("WxPayPubHelper.php");
class WxPay {
	var $return_url="http://wxg.hlyclub.com/Home/Ucenter/index";
	var $notify_url=\WxPayConf_pub::NOTIFY_URL;
	
	function __construct(){
		
	}
	
	function set_return_url($return_url){
		$this->return_url=$return_url;
	}
	
	function set_notify_url($notify_url){
		$this->notify_url=$notify_url;
	}
	
	function get_code($order){
		//使用jsapi接口
		$jsApi = new \JsApi_pub();
		if(!isset($_GET['code'])){
			//触发微信返回code码
			$redirect_uri=urlencode($this->get_url());
			$url = $jsApi->createOauthUrlForCode($redirect_uri);
			Header("Location: $url");
		}else{
			$code = $_GET['code'];
			$jsApi->setCode($code);
			$openid = $jsApi->getOpenId();
			//使用统一支付接口
			$unifiedOrder = new \UnifiedOrder_pub();
			//设置统一支付接口参数
			$unifiedOrder->setParameter("openid",		$openid);
			$unifiedOrder->setParameter("body",			$order['body']);//商品描述
			$unifiedOrder->setParameter("out_trade_no",	$order['out_trade_no']);//商户订单号
			$unifiedOrder->setParameter("total_fee",	$order['total_fee']*100);//总金额
			$unifiedOrder->setParameter("notify_url",	$this->notify_url);//通知地址
			$unifiedOrder->setParameter("trade_type",	"JSAPI");//交易类型
			//非必填参数，商户可根据实际情况选填
			$prepay_id = $unifiedOrder->getPrepayId();
			//=========步骤3：使用jsapi调起支付============
			$jsApi->setPrepayId($prepay_id);
			$jsApiParameters = $jsApi->getParameters();
			$pay_btn=$this->getbutton($jsApiParameters);
			return $pay_btn;
		}
	}
	
	function getbutton($jsApiParameters){
		$button = <<<EOT
				<script type="text/javascript">
		//调用微信JS api 支付
		function jsApiCall()
		{
			WeixinJSBridge.invoke(
				'getBrandWCPayRequest',
				{$jsApiParameters},
				function(res){
                    var return_url="$this->return_url";
					if(res.err_msg == "get_brand_wcpay_request:ok"){
						 
                    }else if (res.err_msg == "get_brand_wcpay_request:cancel") {
                    	alert('支付已取消！');
                    }else{
                        alert("支付失败!");
                    }
                    if(return_url ==''){
						window.location.href='./Home/Ucenter/index';	
					}else{
						window.location.href=return_url;
					}
				}
			);
		}
	
		function callpay()
		{
			if (typeof WeixinJSBridge == "undefined"){
			    if( document.addEventListener ){
			        document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
			    }else if (document.attachEvent){
			        document.attachEvent('WeixinJSBridgeReady', jsApiCall);
			        document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
			    }
			}else{
			    jsApiCall();
			}
		}
	</script>
EOT;
		return $button;
	}
	
	/**
	 * 响应操作
	 */
	function respond(){
		//使用通用通知接口
		$notify = new Notify_pub();
		//存储微信的回调
		$xml = $GLOBALS['HTTP_RAW_POST_DATA'];
		$notify->saveData($xml);
		//验证签名，并回应微信。
		//对后台通知交互时，如果微信收到商户的应答不是成功或超时，微信认为通知失败，
		//微信会通过一定的策略（如30分钟共8次）定期重新发起通知，
		//尽可能提高通知的成功率，但微信不保证通知最终能成功。
		if($notify->checkSign() == FALSE){
			$notify->setReturnParameter("return_code","FAIL");//返回状态码
			$notify->setReturnParameter("return_msg","签名失败");//返回信息
		}else{
			$notify->setReturnParameter("return_code","SUCCESS");//设置返回码
		}
		$returnXml = $notify->returnXml();
		echo $returnXml;
		//==商户根据实际情况设置相应的处理流程，此处仅作举例=======
		if($notify->checkSign() == TRUE){
			if ($notify->data["return_code"] == "FAIL") {
				//此处应该更新一下订单状态，商户自行增删操作【通信出错】
				//$log_->log_result($log_name,":\n".$xml."\n");
				return false;
			}elseif($notify->data["result_code"] == "FAIL"){
				//此处应该更新一下订单状态，商户自行增删操作【业务出错】
				//$log_->log_result($log_name,":\n".$xml."\n");
				return false;
			}else{
				//此处应该更新一下订单状态，商户自行增删操作【支付成功】
				$order_sn=$notify->data['out_trade_no'];
				$temp=explode('_', $order_sn);
				$log_id=$temp[0];
				return $log_id;
			}
		}else{
			return false;
		}
	}
	
	function get_url() {
		$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
		$php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
		$path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
		$relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
		return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
	}
}