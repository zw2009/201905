<?php
use think\Db;
function area_name($code){
	return db('Area')->WHERE('code',$code)->value('name');
}
function format_trange($date){
    $date=explode('_',$date);
    $type=isset($date[0])?$date[0]:'';
    if($type=='y'){
        $type='year';
    }elseif($type=='m'){
        $type='month';
    }elseif($type=='d'){
        $type='day';
    }else{
        return '';
    }
    $nums=isset($date[1])?intval($date[1]):'1';
    if($type=='day') $nums--;
    $stime=strtotime('-'.$nums.' '.$type);
    $start=date('Y-m-d 00:00:00',$stime);
    return $start;
}
/*
 * 自动完成
 * */
function autoAction(){
    set_time_limit(0);
    //1.确认收货(天)
    $confirm_receive=model('Config')->get_config('confirm_receive');
    $confirm_receive=intval($confirm_receive)>0?intval($confirm_receive):0;
    if($confirm_receive>0){
        $time=time()-$confirm_receive*24*60*60;
        $data=Db::name('OrderInfo')
            ->where('status','3')
            ->where('delivery_time','<=',$time)
            ->select();
        if($data){
            foreach ($data as $k=>$v){
                Db::startTrans();
                $ret=model('OrderInfo')->order_receive($v['id']);
                if($ret===true) Db::commit();
            }
        }
    }
    //2.取消订单（时）
    $confirm_cancel=model('Config')->get_config('confirm_cancel');
    $confirm_cancel=round($confirm_cancel,2)>0?round($confirm_cancel,2):0;
    if($confirm_cancel>0){
        $time=round(time()-$confirm_cancel*60*60);
        $data=Db::name('OrderInfo')
            ->where('status','1')
            ->where('create_time','<=',$time)
            ->select();
        if($data){
            foreach ($data as $k=>$v){
                Db::startTrans();
                $ret=model('OrderInfo')->order_cancel($v['id']);
                if($ret===true) Db::commit();
            }
        }
    }
    //3.确认上课(天)
    $confirm_finish=model('Config')->get_config('confirm_finish');
    $confirm_finish=intval($confirm_finish)>0?intval($confirm_finish):0;
    if($confirm_finish>0){
        $time=time()-$confirm_finish*24*60*60;
        $data=Db::name('BookSchedule')
            ->where('status','2')
            ->where('finish_time','<=',$time)
            ->select();
        if($data){
            foreach ($data as $k=>$v){
                Db::startTrans();
                $ret=model('Book')->order_confirm($v['id']);
                if($ret===true) Db::commit();
            }
        }
    }
}