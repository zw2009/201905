<?php
use Org\OpenSSL;
use think\response\View;
/**
 * 过滤/字符串处理方法
 *   */
/**
 * 图片状态
 * @param unknown $status
 * @return string  */
function yes_or_no($status){
	$yes=config('view_replace_str.__COMMON__')."/images/yes.gif";
	$no=config('view_replace_str.__COMMON__')."/images/no.gif";
	return $status?"<img src=$yes>":"<img src=$no>";
}
/**
 * 手机号加密
 * @param unknown $mobile
 * @return mixed  */
function encode_mobile($mobile){
	return substr_replace($mobile, '****', 3, 4);
}

/**
 * 富文本内容处理
 * @param unknown $content
 * @return string  */
function format_content($content){
	return htmlspecialchars_decode(stripslashes($content));
}


/**
 * 微信昵称表情过滤
 * @param unknown $str
 * @return mixed  */
function prCallback($data){
	return "";
}
function filter_nickname($str){
	$str=json_encode($str);
	$nickname=json_decode(preg_replace_callback('#(\\\ud[0-9a-f]{3}|\\\u2(6|7)[0-9a-f]{2})#i',"prCallback",$str));
	return $nickname;
}

/**
 * 字符串截取
 * @param unknown $str
 * @param number $start
 * @param unknown $length
 * @param string $charset
 * @param string $suffix  */
function cut_str($string, $sublen, $start = 0, $code = 'UTF-8') {
	if ($code == 'UTF-8') {
		$pa = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";
		preg_match_all ( $pa, $string, $t_string );
		if (count ( $t_string [0] ) - $start > $sublen)
			return join ( '', array_slice ( $t_string [0], $start, $sublen ) ) . "...";
			return join ( '', array_slice ( $t_string [0], $start, $sublen ) );
	} else {
		$start = $start * 2;
		$sublen = $sublen * 2;
		$strlen = strlen ( $string );
		$tmpstr = '';
		for($i = 0; $i < $strlen; $i ++) {
			if ($i >= $start && $i < ($start + $sublen)) {
				if (ord ( substr ( $string, $i, 1 ) ) > 129) {
					$tmpstr .= substr ( $string, $i, 2 );
				} else {
					$tmpstr .= substr ( $string, $i, 1 );
				}
			}
			if (ord ( substr ( $string, $i, 1 ) ) > 129)
				$i ++;
		}
		if (strlen ( $tmpstr ) < $strlen)
			$tmpstr .= "...";
		return $tmpstr;
	}
}

/**
 * url分析
 * @param unknown $url
 * @return multitype:string mixed Ambigous <unknown, mixed, void, NULL> unknown Ambigous <mixed, void, NULL> Ambigous <mixed, void, NULL, multitype:>  */
function parseUrl($url) {
	$var=$return=array();
	$url_model=config('url_common_param');
	if($url_model){
        //$url="http://localhost/fbb?m=Home&c=Index&a=index";
        $pathinfo=parse_url($url);
        $path=$pathinfo['query'];
        parse_str($path,$var);
        $return['m']=$var['m']?$var['m']:config('default_module');
        $return['c']=$var['c']?$var['c']:config('default_controller');
        $return['a']=$var['a']?$var['a']:config('default_action');

	}else{
        //$url="http://localhost/index.php/Home/Index/index";
        $pathinfo=parse_url($url);
        $path   = array_filter(explode(config('pathinfo_depr'),$pathinfo['path']));
        if($path && is_array($path)){
            foreach ($path as $k=>$v){
                if(strtolower($v)===strtolower(request()->module())){
                    $return['m']=$v;
                    $m_k=$k;
                    break;
                }
            }
            $return['m']=isset($return['m'])?$return['m']:config('default_module');
            $return['c']=(isset($path[$m_k+1]) && isset($m_k))?$path[$m_k+1]:config('default_controller');
            $return['a']=(isset($path[$m_k+2]) && isset($m_k))?$path[$m_k+2]:config('default_action');
        }
	}
	$return['m']=!isset($return['m'])?'':strtolower($return['m']);
	$return['c']=!isset($return['c'])?'':urlcfirst($return['c']);
	$return['a']=!isset($return['a'])?'':str_replace(".".config('url_html_suffix'),'', $return['a']);
	return $return;
}

/*获取当前完整地址*/
function get_url() {
	$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
	$php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
	$path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
	$relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
	return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
}
/*设置完整url  */
function set_url($url){
	$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
	$php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
	return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$url;
}

function cur_url($var){
	$param=input('param.');
	if(is_array($var)) $param=array_merge($param,$var);
	return  url(MODULE_NAME."/".CONTROLLER_NAME."/".ACTION_NAME,$param);
}
/**

* PHP清除html、css、js格式并去除空格的PHP函数,并具有截取UTF-8字符串的作用

*/

function cutstr_html($string, $sublen){

	$string = strip_tags(htmlspecialchars_decode($string));

	$string = preg_replace ('/\n/is', '', $string);

	$string = preg_replace ('/ |　/is', '', $string);

	$string = preg_replace ('/&nbsp;/is', '', $string);

	preg_match_all("/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/", $string, $t_string);

	if(count($t_string[0]) - 0 > $sublen) $string = join('', array_slice($t_string[0], 0, $sublen))."…";

	else $string = join('', array_slice($t_string[0], 0, $sublen));

	return $string;

}

/**
 * 去除内容中的图片
 * @param unknown $content
 * @return string  */
function strip_img($content){
	return preg_replace('/<img[^>]*\>/','',$content);
}

/**
 * 格式化字节大小
 * @param  number $size      字节数
 * @param  string $delimiter 数字和单位分隔符
 * @return string            格式化后的带单位的大小
 * @author 麦当苗儿 <zuojiazi@vip.qq.com>
 */
function format_bytes($size, $delimiter = '') {
	$units = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
	for ($i = 0; $size >= 1024 && $i < 5; $i++) $size /= 1024;
	return round($size, 2) . $delimiter . $units[$i];
}
/**
 * 获取两个坐标点的实际距离
 * @param unknown $lng1
 * @param unknown $lat1
 * @param unknown $lng2
 * @param unknown $lat2
 * @return number  */
function get_distance($lng1,$lat1, $lng2, $lat2){ 
	$radLat1 = $lat1 * (pi() / 180);
	$radLat2 = $lat2 * (pi() / 180);
   
	$a = $radLat1 - $radLat2; 
	$b = ($lng1 * (pi() / 180)) - ($lng2 * (pi() / 180)); 
   
	$s = 2 * asin(sqrt(pow(sin($a/2),2) + cos($radLat1)*cos($radLat2)*pow(sin($b/2),2))); 
	$s = $s * 6371*1000; 
	
	if($s<500){
		$s="<500m";
	}else{
		$s=round($s/1000,2)."km";
	}
	return $s; 
}
/**
 * 产生随机字串，可用来自动生成密码
 * 默认长度6位 字母和数字混合 支持中文
 * @param string $len 长度
 * @param string $type 字串类型
 * 0 字母 1 数字 其它 混合
 * @param string $addChars 额外字符
 * @return string
 */
function randString($len=6,$type='',$addChars='') {
	$str ='';
	switch($type) {
		case 0:
			$chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.$addChars;
			break;
		case 1:
			$chars= str_repeat('0123456789',3);
			break;
		case 2:
			$chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.$addChars;
			break;
		case 3:
			$chars='abcdefghijklmnopqrstuvwxyz'.$addChars;
			break;
		default :
			// 默认去掉了容易混淆的字符oOLl和数字01，要添加请使用addChars参数
			$chars='ABCDEFGHIJKMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789'.$addChars;
			break;
	}
	if($len>10 ) {//位数过长重复字符串一定次数
		$chars= $type==1? str_repeat($chars,$len) : str_repeat($chars,5);
	}

	$chars   =   str_shuffle($chars);
	$str     =   substr($chars,0,$len);

	return $str;
}
/**
 * 生成订单号
 * @return string  */
function set_order_no(){
	return date('Ymd').substr(time(),-5).substr(microtime(),2,3).randString(4,1);
}
/**
 * 图片地址处理
 * @param unknown $pic
 * @return string  */
function filterPic($pic){
	if($pic) return request()->root(true).$pic;
}
/**
 * openssl加密
 *   */
function encryptPublic($data){
	if(is_array($data)){
		$data=json_encode($data);
	}
	//中文处理
	$pa = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";
	preg_match_all ( $pa, $data, $t_string );
	
	$t_string=implode('',$t_string[0]);
	while(strlen($t_string)>0){
		$openSSL = OpenSSL::getOpenSSLInstance(PUCBLIC_KEY_PATH,PRIVATE_KEY_PATH);
		$temp=substr($t_string,0,117);
		$t_string=substr($t_string,strlen($temp));
		//公钥加密私钥解密
		$arr[]=$openSSL->encryptPublic($temp);
	}
	return $arr;
}
/**
 * openssl解密
 *   */
function decryptPrivate($data){
	$data=json_decode($data);
	$openSSL = OpenSSL::getOpenSSLInstance(PUCBLIC_KEY_PATH,PRIVATE_KEY_PATH);
	$param='';
	foreach ($data as $str){
		$param.=$openSSL->decryptPrivate($str);
	}
	$param = json_decode($param,true);
	return $param;
}
/**
 * 数组转对象
 * @param unknown $array
 * @return Ambigous <StdClass, unknown>  */
function array2object($array) {
	if (is_array($array)) {
		$obj = new StdClass();
		foreach ($array as $key => $val){
			$obj->$key = $val;
		}
	}
	else { $obj = $array; }
	return $obj;
}
/**
 * 对象转数组
 * @param unknown $object
 * @return unknown  */
function object2array($object) {
	if (is_object($object)) {
		$array=null;
		foreach ($object as $key => $value) {
			$array[$key] = $value;
		}
	} else {
		$array = $object;
	}
	return $array;
}

function replacePicUrl($content = null, $strUrl = null) {
	if($strUrl===null) $strUrl=request()->root(true);
	if ($strUrl) {
		$content=htmlspecialchars_decode(stripslashes($content));
		//提取图片路径的src的正则表达式 并把结果存入$matches中
		preg_match_all("/<img(.*)src=\"([^\"]+)\"[^>]+>/isU",$content,$matches);
		$img = "";
		if(!empty($matches)) {
			//注意，上面的正则表达式说明src的值是放在数组的第三个中
			$img = $matches[2];
		}else {
			$img = "";
		}
		if (!empty($img)) {
			$patterns= array();
			$replacements = array();
			foreach($img as $imgItem){
				$final_imgUrl = $strUrl.$imgItem;
				$replacements[] = $final_imgUrl;
				$img_new = "/".preg_replace("/\//i","\/",$imgItem)."/";
				$patterns[] = $img_new;
			}

			//让数组按照key来排序
			ksort($patterns);
			ksort($replacements);

			//替换内容
			$vote_content = preg_replace($patterns, $replacements, $content);

			return $vote_content;
		}else {
			return $content;
		}
	} else {
		return $content;
	}
}
/* *
 * 获取整个html
*  */
function get_content($content,$title){
	$view = new View('Index/content');
	$view->assign('content',$content);
	$view->assign('title',$title);
	return $view->getContent();
}