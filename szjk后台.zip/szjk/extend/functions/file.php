<?php
function filename_rule(){
	$filename=date('Ymd')."/";
	$filename.=uniqid();
	$filename.=randString(5);
	return $filename;
}
function uploads_file($file_name,$dir){
    $file = request()->file($file_name);
    // 移动到框架应用根目录/public/uploads/ 目录下
    $root=ROOT_PATH . 'public/uploads/'.$dir;
    $info = $file->rule('filename_rule')->move($root);
    if($info){
        //将\换成/
        $data=$info->getSaveName();
        return array('code'=>1,'data'=>$data);
    }else{
        return array('code'=>0,'msg'=>$file->getError());
    }
}
/**
 * 上传单个文件
 * @param $file_name
 * @param bool $is_thumb
 * @param int $width
 * @param int $height
 * @return array
 */
function uploads_single($file_name,$is_thumb=false,$width=0,$height=0) {
	if(!$_FILES[$file_name]['name']) return ['code'=>0,'msg'=>'上传文件不存在！']; 
    $file = request()->file($file_name);
    // 移动到框架应用根目录/public/uploads/ 目录下
    $root=ROOT_PATH . 'public/uploads/image';
    $info = $file->rule('filename_rule')->move($root);
    if($info){
    	if($is_thumb==true){
			$image = \think\Image::open('./uploads/image/'.$info->getSaveName());
			$image->thumb($width, $height,3)->save('./uploads/image/'.$info->getSaveName());
		}
		//将\换成/
		$data=$info->getSaveName();
		return array('code'=>1,'data'=>$data);
    }else{
        return array('code'=>0,'msg'=>$file->getError());
    }
}

/**
 * 上传多文件
 * @param $file_name
 * @param bool $is_thumb
 * @param int $width
 * @param int $height
 * @return array
 */
function uploads_muilt($file_name,$is_thumb=false,$width=0,$height=0){
	$files = request()->file($file_name);
	$data=$error=null;
	foreach($files as $k=>$file){
		// 移动到框架应用根目录/public/uploads/ 目录下
		$root=ROOT_PATH . 'public/uploads/image';
		$info = $file->move($root);
		if($info){
			if($is_thumb==true){
				$image = \think\Image::open('./uploads/image/'.$info->getSaveName());
				$image->thumb($width, $height,3)->save('./uploads/image/'.$info->getSaveName());
			}
			$data[$k]=$info->getSaveName();
		}else{
			$error[]=$file->getError();
		}
	}
	return array('code'=>1,'data'=>$data,'error'=>$error);
}

/**
 * 上传文件
 * @param bool $is_thumb
 * @param int $width
 * @param int $height
 * @return array|mixed
 */
function uploadify($is_thumb=false,$width=0,$height=0) {
	$filename=array_keys($_FILES);
	$files = request()->file($filename[0]);
	// 移动到框架应用根目录/public/uploads/ 目录下
	$root=ROOT_PATH . 'public/uploads/image';
	$info = $files->move($root);
	if($info){
		if($is_thumb==true && $width>0 && $height>0){
			$image = \think\Image::open('./uploads/image/'.$info->getSaveName());
			$image->thumb($width, $height,3)->save('./uploads/image/'.$info->getSaveName());
		}
		$img=array(
				'path'=>$info->getSaveName(),
				'alt'=>$info->getFilename()
		);
		return $img;
	}else{
		return $files->getError();
	}
}
/**
 * 保存base64图片，并返回图片信息
 * @param unknown $img
 * @return multitype:string number |boolean  */
function saveBase64Img($img){
	if(strstr($img,'data:image/png;base64,')){
		$data= base64_decode(str_replace('data:image/png;base64,', '', $img));
		$rootPath=config('UPLOAD_IMG');
		$savepath=date('Ymd')."/";
		if(!is_dir($rootPath.$savepath)) {
			mkdir($rootPath.$savepath, 0777, true);
		}
		$savename=uniqid () . '.png';
		$file=$rootPath.$savepath.$savename;
		// 将图片数据写入文件
		$success = file_put_contents ( $file , $data ) ;
		if($success){
			//上传成功，获取图片信息，并存入数据库
			$file_info=array(
					'savename'=>$savename,
					'savepath'=>$savepath,
					'size'=>filesize($file),
					'md5'=>md5_file($file),
					'sha1'=>sha1_file($file)

			);
			return $file_info;
		}
	}
	return false;
}

/**
 * 导出excel表格
 * @param string $filename
 * @param array $data
 * 数组格式1
 *  array(
 *  	array(
 *  		'key1'=>'value1',
 *  		'key2'=>'value2',
 *  		...
 *  	),
 *  	array(
 *  		'key1'=>'value1',
 *  		'key2'=>'value2',
 *  		...
 *  	),
 *  	...
 *  );
 *  数组格式2
 *  array(
 *  	array(
 *  		'key1'=>'value1',
 *  		'key2'=>'value2',
 *  		'key3'=>array(
 *  			array(
 *  				'key1'=>'value1',
 *  				'key2'=>'value2',
 *  				...
 *  			),
 *  			array(
 *  				'key1'=>'value1',
 *  				'key2'=>'value2',
 *  				...
 *  			),
 *  			...
 *  		),
 *  		'key4'=>'value5',
 *  		...
 *  	),
 *  	array(
 *  		'key1'=>'value1',
 *  		'key2'=>'value2',
 *  		'key3'=>array(
 *  			array(
 *  				'key1'=>'value1',
 *  				'key2'=>'value2',
 *  				...
 *  			),
 *  			array(
 *  				'key1'=>'value1',
 *  				'key2'=>'value2',
 *  				...
 *  			),
 *  			...
 *  		),
 *  		'key4'=>'value5',
 *  		...
 *  	),
 *  	...
 *  )
 *
 * */
function explodeExcel($filename,$data){
	$field=$data[0];
	import('PHPExcel', EXTEND_PATH."Org/PHPExcel/");
	$objPHPExcel = new \PHPExcel();
	$objWriter = new \PHPExcel_Writer_Excel2007($objPHPExcel);
	$objWriter->setOffice2003Compatibility(true);
	//设置表格头
	$head=array();
	$count=count($field);
	$j=0;
	for ($i = 'A'; $i <= 'Z'; $i++){
		$j++;
		$head[]="$i";
		if ($j>=$count) break;
	}
	//设置单元格内容
	$field=array_keys($field);
	$col=1;
	foreach($data as $k=>$v){
		//判断
		foreach($v as $key=>$val){
			if(is_array($val)){
				$arrlen=count($val);
			}
		}
		if(isset($arrlen)){
			//数组格式2
			foreach($v as $key=>$val){
				if(is_array($val)){
					foreach($val as $j=>$value){
						foreach($value as $sort=>$item){
							if(in_array($sort,$field)){
								for($i=0;$i<count($field);$i++){
									if($sort==$field[$i]){
										$objPHPExcel->getActiveSheet()->setCellValue($head[$i] . ($col+$j), $item);
									}
								}
							}
						}
					}
				}else{
					if(in_array($key,$field)){
						for($i=0;$i<count($field);$i++){
							if($key==$field[$i]){
								$objPHPExcel->getActiveSheet()->mergeCells($head[$i] . $col.':'.$head[$i] . ($col+($arrlen-1)));
								$objPHPExcel->getActiveSheet()->setCellValue($head[$i] . $col, $val);
								//垂直局中
								$objPHPExcel->getActiveSheet()->getStyle($head[$i] . $col)->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
							}
						}
					}
				}
			}
			$col=$col+$arrlen;
		}else{
			//数组格式1
			foreach($v as $key=>$val){
				if(in_array($key,$field)){
					for($i=0;$i<count($field);$i++){
						if($key==$field[$i]){
							$objPHPExcel->getActiveSheet()->setCellValue($head[$i] . $col, $val);
						}
					}
				}
			}
			$col++;
		}
	}

	//下载
	header("Pragma: public");
	header("Expires: 0");
	header("Cache-Control:must-revalidate, post-check=0, pre-check=0");
	header("Content-Type:application/force-download");
	header("Content-Type:application/vnd.ms-execl");
	header("Content-Type:application/octet-stream");
	header("Content-Type:application/download");;
	header('Content-Disposition:attachment;filename="'.$filename.".xlsx");
	header("Content-Transfer-Encoding:binary");
	$objWriter->save('php://output');
}

/**
 * excel导入
 * @param string $file 文件地址
 * @return array 返回二位数组  */
function implodeExcel($file){

	if(!file_exists($file)) return false;

	$info = pathinfo($file);

	//下面的路径按照你PHPExcel的路径来修改
	import('PHPExcel', EXTEND_PATH."vendor/PHPExcel/PHPExcel/");
	import('IOFactory', EXTEND_PATH."vendor/PHPExcel/PHPExcel/");
	import('Excel2007', EXTEND_PATH."vendor/PHPExcel/PHPExcel/Reader/");
	import('Excel5', EXTEND_PATH."vendor/PHPExcel/PHPExcel/Reader/");
	
	if( $info['extension'] =='xlsx' ){
		$objReader = PHPExcel_IOFactory::createReader('Excel2007');
	}else{
		$objReader = PHPExcel_IOFactory::createReader('Excel5');
	}
	$objPHPExcel = $objReader->load($file);
	$sheet = $objPHPExcel->getSheet(0);
	$highestRow = $sheet->getHighestRow();           //取得总行数
	$highestColumn = $sheet->getHighestColumn(); //取得总列数

	$res=array();

	//循环读取excel文件
	for($j=1;$j<=$highestRow;$j++){
		//从第一行开始读取数据
		for($k='A';$k<=$highestColumn;$k++){
			//从A列读取数据
			//读取单元格
			$res[$j][$k]=$objPHPExcel->getActiveSheet()->getCell("$k$j")->getValue().'';
		}
	}
	return $res;
}


/**
 * 删除制定文件夹及文件
 * @param unknown $dir
 * @return boolean  */
function deldir($dir) {
	//先删除目录下的文件：
	$dh=opendir($dir);
	while (!!$file=readdir($dh)) {
		if($file!="." && $file!="..") {
			$fullpath=$dir."/".$file;
			if(!is_dir($fullpath)) {
				unlink($fullpath);
			} else {
				deldir($fullpath);
			}
		}
	}
	closedir($dh);
	//删除当前文件夹：
	if(rmdir($dir)) {
		return true;
	} else {
		return false;
	}
}