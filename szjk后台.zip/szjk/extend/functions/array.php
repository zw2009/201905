<?php
/**
 *数组处理方法
 * */

/**
 * 把返回的数据集转换成Tree
 * @param array $list 要转换的数据集
 * @param string $pid parent标记字段
 * @param string $level level标记字段
 * @return array
 */
function list_to_tree($list, $pk='id', $pid = 'parent_id', $child = 'child', $root = 0) {
	// 创建Tree
	$tree = array();
	if(is_array($list)) {
		// 创建基于主键的数组引用
		$refer = array();
		foreach ($list as $key => $data) {
			$refer[$data[$pk]] =& $list[$key];
		}
		foreach ($list as $key => $data) {
			// 判断是否存在parent
			$parentId =  $data[$pid];
			if ($root == $parentId) {
				$tree[] =& $list[$key];
			}else{
				if (isset($refer[$parentId])) {
					$parent =& $refer[$parentId];
					$parent[$child][] =& $list[$key];
				}
			}
		}
	}
	return $tree;
}
/**
 * 将list_to_tree的树还原成列表
 * @param  array $tree  原来的树
 * @param  string $child 子节点的键
 * @param  string $order 排序显示的键，一般是主键 升序排列
 * @param  array  $list  过渡用的中间数组，
 * @return array        返回排过序的列表数组
 * @author yangweijie <yangweijiester@gmail.com>
 */
function tree_to_list($tree, $child = 'child', $order='id', &$list = array()){
	if(is_array($tree)) {
		$refer = array();
		foreach ($tree as $key => $value) {
			$reffer = $value;
			if(isset($reffer[$child])){
				unset($reffer[$child]);
				tree_to_list($value[$child], $child, $order, $list);
			}
			$list[] = $reffer;
		}
		//$list = list_sort_by($list, $order, $sortby='asc');
	}
	return $list;
}
/**
 * 无限级分类形成如：
 * |-一级分类
 * 　|-二级分类
 * 　　　　|-三级分类
 *
 * @param array $cate所有分类
 * @param string $id分类数组的主键字段名
 * @param string $parent_id 分类的所属分类的字段名
 * @param number $pid 初始父级id值
 * @param number $level 当前级别
 * @param string $html
 * @return array返回格式化后的数组
 */
function unlimitedForCat($cate,$id='id',$parent_id='parent_id',$pid=0,$level=0,$html='　'){
	$arr=array();
	foreach($cate as $v){
		if($v[$parent_id]==$pid){
			$v['html']=$level?str_repeat($html,$level)."|— ":'';
			$v['level']=$level;
			$arr[]=$v;
			$arr=array_merge($arr,unlimitedForCat($cate,$id,$parent_id,$v[$id],$level+1,$html));
		}
	}
	return $arr;
}

/**
 * 获取当前分类的所有父级分类
 * @param array $cate 所有分类
 * @param int $id 当前分类id
 * @param string $id_name 分类数据主键字段名
 * @param string $parent_name 分类数据上级字段名
 * @return array  */
function getParents($cate,$id,$id_name='id',$parent_name='parent_id'){
	$arr=array();
	foreach($cate as $v){
		if($v[$id_name] == $id){
			$arr[]=$v;
			$arr = array_merge($arr,getParents($cate,$v[$parent_name]));
		}
	}
	return $arr;
}

/**
 * 获取当前分类的所有父级分类id
 * @param array $cate 所有分类
 * @param int $id 当前分类id
 * @param string $id_name 分类数据主键字段名
 * @param string $parent_name 分类数据上级字段名
 * @return array  */
function getParentsId($cate,$id,$id_name='id',$parent_name='parent_id'){
	$arr=array();
	foreach($cate as $v){
		if($v[$id_name] == $id){
			$arr[]=$v[$parent_name];
			$arr = array_merge($arr,getParentsId($cate,$v[$parent_name],$id_name,$parent_name));
		}
	}
	return $arr;
}
/* *
 * 获取当前分类的顶级分类id
 * @param array $cate 所有分类
 * @param int $id 当前分类id
 * @param string $id_name 分类数据主键字段名
 * @param string $parent_name 分类数据上级字段名
 *  */
function getTopParentsId($cate,$id,$id_name='id',$parent_name='parent_id'){
	if($id==0) return 0;
	$arr=array();
	foreach($cate as $v){
		$arr[$v[$id_name]]=$v[$parent_name];
	}
	while(isset($arr[$id]) && $arr[$id]) {
		$id = $arr[$id];
	}
	return $id;
}

/**
 * 获取当前分类下的所有子分类id
 * @param array $cate 所有分类
 * @param int $pid 当前分类id
 * @param int $include 是否包含当前分类
 * @param string $id_name 分类数据主键字段名
 * @param string $parent_name 分类数据上级字段名
 * @return array  */
function getChildsId($cate ,$pid,$include=false,$id_name='id',$parent_name='parent_id'){
	$arr =array();
	if($include==true) $arr[]=$pid;
	foreach($cate as $v){
		if($v[$parent_name]==$pid){
			$arr[]=$v[$id_name];
			$arr=array_merge($arr,getChildsId($cate,$v[$id_name],false));
		}
	}
	return $arr;
}