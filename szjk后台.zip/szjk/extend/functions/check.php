<?php
/**
 * 验证用户名
 * @param unknown $nick_name
 * @return boolean  */
function check_nick_name($nick_name){
	$nickname=json_decode(preg_replace("#(\\\\ud[0-9a-f]{3}|\\\\u2(6|7)[0-9a-f]{2})#ie","",json_encode($nick_name)));
	if(preg_match("/^\\S{1,50}$/",$nick_name)){
		return true;
	}
	return false;
}
/**
 * 判断是否有中文
 * @param unknown $string
 * @return boolean  */
function hasNoChinese($string){
	if (preg_match("/[\x7f-\xff]/", $string)) {
		return false;
	}else{
		return true;
	}
}
/**
 * 判断字符串中是否存在html标签
 * @param unknown $str
 * @return boolean  */
function checkHtml($str){
	if($str != strip_tags($str)){
		return true;
	}else{
		return false;
	}
}
/**
 * 验证登录账号
 * @return boolean  */
function check_login_name($login_name){
	if(preg_match("/^\\S{1,20}$/",$login_name) && hasNoChinese($login_name)){
		return true;
	}
	return false;
}
/**
 * 验证密码
 * @return boolean  */
function check_password($password){
	if(preg_match("/^[\\S]{6,}$/",$password)){
		return true;
	}
	return false;
}
function check_encrypt_password($password){
	if(strlen($password)=='32'){
		return true;
	}
	return false;
}
/**
 * 验证手机号码
 * @param unknown $mobile
 * @return boolean  */
function check_mobile($mobile){
	if(preg_match("/^1\\d{10}$/",$mobile)){
		return true;
	}
	return false;
}
/**
 * 验证手机验证码
 * @param unknown $mobile
 * @return boolean  */
function check_mobile_code($mobile,$code){
	//return $code=='1234'?true:false;
	//验证验证码
	$map=array(
			'mobile'=>$mobile,
			'code'=>$code
	);
	$verify=db('VerifyCode')->where($map)->order('create_time DESC')->find();
	if($verify['validity']<time() || !$verify) return false;
	return true;
}
/**
 * 验证验证码
 * @param unknown $verify
 * @return boolean  */
function check_verify($verify){
	return captcha_check($verify);
}
/* 验证身份证号开始 */
/**
 * 验证身份证
 * @param unknown $id_card
 * @return boolean  */
function check_idcard($id_card){
	if(strlen($id_card)==18){
		return idcard_checksum18($id_card);
	}elseif((strlen($id_card)==15)){
		$id_card=idcard_15to18($id_card);
		return idcard_checksum18($id_card);
	}else{
		return false;
	}
}
// 计算身份证校验码，根据国家标准GB 11643-1999
function idcard_verify_number($idcard_base){
	if(strlen($idcard_base)!=17){
		return false;
	}
	//加权因子
	$factor=array(7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2);
	//校验码对应值
	$verify_number_list=array('1','0','X','9','8','7','6','5','4','3','2');
	$checksum=0;
	for($i=0;$i<strlen($idcard_base);$i++){
		$checksum += substr($idcard_base,$i,1) * $factor[$i];
	}
	$mod=$checksum % 11;
	$verify_number=$verify_number_list[$mod];
	return $verify_number;
}
// 将15位身份证升级到18位
function idcard_15to18($idcard){
	if(strlen($idcard)!=15){
		return false;
	}else{
		// 如果身份证顺序码是996 997 998 999，这些是为百岁以上老人的特殊编码
		if(array_search(substr($idcard,12,3),array('996','997','998','999')) !== false){
			$idcard=substr($idcard,0,6).'18'.substr($idcard,6,9);
		}else{
			$idcard=substr($idcard,0,6).'19'.substr($idcard,6,9);
		}
	}
	$idcard=$idcard.idcard_verify_number($idcard);
	return $idcard;
}
// 18位身份证校验码有效性检查
function idcard_checksum18($idcard){
	if(strlen($idcard)!=18){
		return false;
	}
	$idcard_base=substr($idcard,0,17);
	if(idcard_verify_number($idcard_base)!=strtoupper(substr($idcard,17,1))){
		return false;
	}else{
		return true;
	}
}
/*** 验证身份证号结束 ***/
/*  */
function check_plate($data){
	if(preg_match("/^[\x80-\xff]+[A-Z][0-9a-zA-Z]{5}$/",$data)){
		return true;
	}
	return false;
}
/**
 * 终端检测
 * @return boolean  */
function ismobile() {
	// 如果有HTTP_X_WAP_PROFILE则一定是移动设备
	if (isset ($_SERVER['HTTP_X_WAP_PROFILE']))
		return true;

	//此条摘自TPM智能切换模板引擎，适合TPM开发
	if(isset ($_SERVER['HTTP_CLIENT']) &&'PhoneClient'==$_SERVER['HTTP_CLIENT'])
		return true;
	//如果via信息含有wap则一定是移动设备,部分服务商会屏蔽该信息
	if (isset ($_SERVER['HTTP_VIA']))
		//找不到为flase,否则为true
		return stristr($_SERVER['HTTP_VIA'], 'wap') ? true : false;
	//判断手机发送的客户端标志,兼容性有待提高
	if (isset ($_SERVER['HTTP_USER_AGENT'])) {
		$clientkeywords = array(
				'nokia','sony','ericsson','mot','samsung','htc','sgh','lg','sharp','sie-','philips','panasonic','alcatel','lenovo','iphone','ipod','blackberry','meizu','android','netfront','symbian','ucweb','windowsce','palm','operamini','operamobi','openwave','nexusone','cldc','midp','wap','mobile'
		);
		//从HTTP_USER_AGENT中查找手机浏览器的关键字
		if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT']))) {
			return true;
		}
	}
	//协议法，因为有可能不准确，放到最后判断
	if (isset ($_SERVER['HTTP_ACCEPT'])) {
		// 如果只支持wml并且不支持html那一定是移动设备
		// 如果支持wml和html但是wml在html之前则是移动设备
		if ((strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') !== false) && (strpos($_SERVER['HTTP_ACCEPT'], 'text/html') === false || (strpos($_SERVER['HTTP_ACCEPT'], 'vnd.wap.wml') < strpos($_SERVER['HTTP_ACCEPT'], 'text/html')))) {
			return true;
		}
	}
	return false;
}

/**
 * 判断是否在微信中打开
 * @return boolean  */
function open_in_weichat(){
	//判断是否微信中打开
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	return  (strpos($user_agent, 'MicroMessenger') == true)?true:false;
}