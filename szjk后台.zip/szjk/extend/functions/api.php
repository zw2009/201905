<?php
function success($data=null,$msg=''){
	$sucCode=array(
        'code'=>'200',
        'msg'=>'操作成功'
	);
	if($data===null){
		return json(array(
				'code'=>'200',
				'msg'=>$msg?$msg:$sucCode['msg']
		));
	}else{
		return json(array(
				'code'=>$sucCode['code'],
				'data'=>$data,
		));
	}
}
function error($msg='',$code='ERROR'){
	$errCode=array(
			'ERROR'=>array(
					'code'=>'400',
					'msg'=>'操作错误'
			),
			'PARAM_ERROR'=>array(
					'code'=>'401',
					'msg'=>'参数错误',
			),
			'GET_ERROR'=>array(
					'code'=>'402',
					'msg'=>'记录不存在',
			),
            'DATA_NULL'=>array(
                'code'=>'403',
                'msg'=>'没有更多数据'
            ),
            'COMPLETE_INFO'=>array(
                'code'=>'404',
                'msg'=>'完善个人资料'
            )
	);
	return json(array(
			'code'=>$errCode[$code]['code'],
			'msg'=>$msg?$msg:$errCode[$code]['msg']
	));
}
/**
 * 远程获取数据
 * @param unknown $url
 * @param string $data
 * @return 获取成功返回解析后的数组，否则返回false  */
function curl_get($url,$data=null){
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	$output = curl_exec($ch);
	curl_close($ch);
	//判断数据结构
	if(!!$xml=xml_parser($output)){
		$output=$xml;
	}elseif (!!$json=json_parser($output)){
		$output=$json;
	}else{
		$output=false;
	}

	return $output;
}
/**
 * 解析XML格式的字符串
 *
 * @param string $str
 * @return 解析正确就返回解析结果,否则返回false,说明字符串不是XML格式
 */
function xml_parser($str){
	$xml_parser = xml_parser_create();
	if(!xml_parse($xml_parser,$str,true)){
		xml_parser_free($xml_parser);
		return false;
	}else {
		return (json_decode(json_encode(simplexml_load_string($str)),true));
	}
}


/**
 * 解析JSON格式的字符串
 *
 * @param string $str
 * @return 解析正确就返回解析结果,否则返回false,说明字符串不是JSON格式
 */
function json_parser($str){
	$arr = json_decode($str,true);
	if(gettype($arr) != "array"){
		return false;
	}else {
		return $arr;
	}
}

/**
 * @param $data
 * @return 解析正确就返回解析结果
 */
function api_data($data){
    //判断数据结构
    if(!!$xml=xml_parser($data)){
        $data=$xml;
    }elseif (!!$json=json_parser($data)){
        $data=$json;
    }
    return $data;
}
/**
 * 调用百度API，根据地址获取经纬度信息
 * @param 地址
 * @return array('lng','lat')|false
 *   */
function getLocation($address){
	if(false==$address) return false;
	$url='http://api.map.baidu.com/geocoder/v2/?address='.$address.'&output=json&ak=PX0frg7nX2VFKws80tUyS5kdr51yTZpD';
	$data=curl_get($url);
	if('OK'!=$data['status']){
		return false;
	}
	return $data['result']['location'];
}
/**
 * 腾讯地图坐标转百度地图坐标
 * @param [String] $lat 腾讯地图坐标的纬度
 * @param [String] $lng 腾讯地图坐标的经度
 * @return [Array] 返回记录纬度经度的数组
 */
function Convert_GCJ02_To_BD09($lat,$lng){
	$x_pi = 3.14159265358979324 * 3000.0 / 180.0;
	$x = $lng;
	$y = $lat;
	$z =sqrt($x * $x + $y * $y) + 0.00002 * sin($y * $x_pi);
	$theta = atan2($y, $x) + 0.000003 * cos($x * $x_pi);
	$lng = $z * cos($theta) + 0.0065;
	$lat = $z * sin($theta) + 0.006;
	return array('lng'=>$lng,'lat'=>$lat);
}
/**
 * 获取中奖项
 * @param unknown $proArr
 * @return Ambigous <string, unknown>  */
function get_prize($proArr) {
	$result = '';
	//概率数组的总概率精度
	$proSum = array_sum($proArr);

	//概率数组循环
	foreach ($proArr as $key => $proCur) {
		$randNum = mt_rand(1, $proSum);
		if ($randNum <= $proCur) {
			$result = $key;
			break;
		} else {
			$proSum -= $proCur;
		}
	}
	unset ($proArr);

	return $result;
}